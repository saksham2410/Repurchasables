<html>  

<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>
	View Records
</title>
</head>

<body>
<?php
echo "<h1>View Records</h1>";
?>

<?php
$username = "user0";
$password = "csl203lab";
$database = "lab";
$table    = "student";

mysql_connect(localhost, $username, $password);

@mysql_select_db($database) or die("Unable to select database");

$query  = "SELECT * FROM $table";
$result = mysql_query($query);
$num    = mysql_num_rows($result);
mysql_close();

?>
<div id="page">
                <div id="nav">
                        <ul>
                                <li><a href="index.html">Home</a></li>
                                <li><a href="mysql_connect.php">View Records</a></li>
                                <li><a href="form.php">Add Records</a></li>
                        </ul>   
                </div>
</div>
 
<table>
<tr>
<th>Name</th>
<th>Entry Number</th>
<th>Place of birth</th>
<th>PIN</th>
<th>State</th>
</tr>

<?php
$i = 0;
while ($i < $num) {
    $name         = mysql_result($result, $i, "Name");
    $entryNumber  = mysql_result($result, $i, "EntryNumber");
    $placeOfBirth = mysql_result($result, $i, "PlaceOfBirth");
    $pin          = mysql_result($result, $i, "PIN");
    $state        = mysql_result($result, $i, "State");
    echo "<tr><td>$name</td><td>$entryNumber</td><td>$placeOfBirth</td><td>$pin</td><td>$state</td></tr>";
    $i++;
}
?>
</table>

</body>
</html>
