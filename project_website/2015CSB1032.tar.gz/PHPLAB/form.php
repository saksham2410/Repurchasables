<html>

<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>
	Add Records
</title>
<style>
	.error {color: #FF0000;}
</style>
</head>
<body>


<?php
$name = $entry = $placeBirth = $pincode = $state = "";
$nameerror = $entryerror = $placeBirtherror = $pincodeerror = $stateerror = "";

function test($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}


/*	$name       = $_POST['name'];
	$entry      = $_POST['entry'];
	$placeBirth = $_POST['placeBirth'];
	$pincode    = $_POST['pincode'];
	$state      = $_POST['state'];
*/

if ($_SERVER["REQUEST_METHOD"] == "POST"){
//if (!empty($_POST)) {
   
	if (empty($_POST["name"])){
		$nameerror = "Name is a required field";
	}	
	else {
		$name = test($_POST['name']);
	    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      		$nameerror = "Only letters and white space allowed";
    	}
	}

 
	if (empty($_POST["entry"])){
		$entryerror = "Entry number is a required field";
	}	
	else {
		$entry = test($_POST['entry']);

	    if (!preg_match("/^[0-9a-zA-Z]*$/",$entry)) {
      		$entryerror = "Only numbers and letters allowed";
    	}
	}
	
	if (empty($_POST["placeBirth"])){
		$placeBirtherror = "Place of Birth is a required field";
	}	
	else {
		$placeBirth = test($_POST['placeBirth']);
	    
	if (!preg_match("/^[a-zA-Z ]*$/",$placeBirth)) {
      		$placeBirtherror = "Only letters and white space allowed";
    	}
	}


	if (empty($_POST["pincode"])){
		$pincodeerror = "Pincode is a required field";
	}	
	else {
		$pincode = test($_POST['pincode']);
	    
	if (!preg_match("/^[0-9]*$/",$pincode)) {
      		$pincodeerror = "Only numbers allowed";
    	}
	}


	if (empty($_POST["state"])){
		$stateerror = "State is a required field";
	}	
	else {
		$state = test($_POST['state']);
	    if (!preg_match("/^[a-zA-Z ]*$/",$state)) {
      		$stateerror = "Only letters and white space allowed";
    	}
	}

	if (empty($nameerror) && empty($entryerror) &&  empty($placeBirtherror) && empty($pincodeerror) && empty($stateerror) ) {
	$username = "user0";
    $password = "csl203lab";
    $database = "lab";
    $table    = "student";
    
    mysql_connect(localhost, $username, $password);
    
    @mysql_select_db($database) or die("Unable to select database");
    
    $query = "INSERT INTO $table VALUES ('$name','$entry','$placeBirth','$pincode','$state')";
    #$query = "INSERT INTO $table("Name", "EntryNumber", "PlaceOfBirth", "PIN", "State") VALUES ($name,$entry,$placeBirth,$pincode,$state)";
    
    mysql_query($query);
    mysql_close();
    echo "<h2>Entry updated</h2>";
	}
	else{
		echo "<h2>There were some errors, entry not updated </h2>";
	}
}
?>

<h1>Add Records</h1>

<div id="page">
                <div id="nav">
                        <ul>
                                <li><a href="index.html">Home</a></li>
                                <li><a href="mysql_connect.php">View Records</a></li>
                                <li><a href="form.php">Add Records</a></li>
                        </ul>
                </div>


                                                                     
<div class="form">
<form action="form.php" method="post">

<h1>  Add Records</h1>    

    <label for="name">Name <span class="error">*</span> 
	<span class="error"><?php echo $nameerror;?></span> 
    <input type="text" id="name" name="name" placeholder="Shivam Mittal">

    <label for="entry">Entry Number </label> <span class="error">*</span>
	<span class="error"><?php echo $entryerror;?></span> 
    <input type="text" id="entry" name="entry" placeholder="2015CSB1032">

    <label for="placeBirth">Place of birth </label><span class="error">*</span>
	<span class="error"><?php echo $placeBirtherror;?></span> 
    <input type="text" id="placeBirth" name="placeBirth" placeholder="Delhi">


    <label for="pincode">PIN </label><span class="error">*</span>
	<span class="error"><?php echo $pincodeerror;?></span> 
    <input type="text" id="pincode" name="pincode" placeholder="110058">

  
    <label for="state">State </label><span class="error">*</span>
	<span class="error"><?php echo $stateerror;?></span> 
    <input type="text" id="state" name="state" placeholder="Ropar">

    <input type="submit" value="Submit">
  </form>
</div>
</div>

</body>
</html>           
